﻿#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
using namespace std;
#define INF 10000000
vector<bool> is_prime;
vector<int> prime;
class PrimeFactorization {
private:
	int num1, num2, GCD;
	long long int LCM;
	vector<int> num1_factor, num2_factor;

public:
	PrimeFactorization() {
		//TO_DO: initial constructor
	}
	PrimeFactorization(int _a, int _b) {
		//TO_DO: _a means the first integer and _b means the second integer
		this->num1 = _a;
		this->num2 = _b;
	}
	void Get_Prime_Factorization() {
		//TO_DO: Prime factorization num1 and num2, push result to the num1_factor and num2_factor.
		int temp = num1;
		for (int i = 0; prime[i] <= sqrt(num1) || temp == 2 || temp == 3; i++) {	//Only need to find the number less than sqrt(num1)
			while (temp % prime[i] == 0) {	//Is the factor of prime number.
				temp /= prime[i];
				num1_factor.push_back(prime[i]);
			}
			if (temp < INF && is_prime[temp] == true) { //In the end, num1 may be prime number, so we need to check whether it is prime number.temp<INF is used to protect the is_prime not to overflow.
				num1_factor.push_back(temp);
				break;
			}
		}
		temp = num2;
		for (int i = 0; prime[i] <= sqrt(num2) || temp == 2 || temp == 3; i++) {	//Only need to find the number less than sqrt(num2).
			while (temp % prime[i] == 0 && temp != 2) {
				temp /= prime[i];
				num2_factor.push_back(prime[i]);
			}
			if (temp < INF && is_prime[temp] == true) { //In the end, num2 may be prime number, so we need to check whether it is prime number.temp<INF is used to protect the is_prime not to overflow.
				num2_factor.push_back(temp);
				break;
			}
		}
	}

	void Print_Prime_Factorization() {
		//TO_DO: Print num1_factor and num2_factor.
		cout << "num1_Prime_factor : \" ";
		for (int i = 0; i < num1_factor.size(); i++) {
			cout << num1_factor[i] << " ";
		}
		cout << "\"" << endl;
		cout << "num2_Prime_factor : \" ";
		for (int i = 0; i < num2_factor.size(); i++) {
			cout << num2_factor[i] << " ";
		}
		cout << "\"" << endl;
	}

	void Print_GCD() {
		//TO_DO: Use num1_factor and num2_factor to find GCD and print the result.
		int i = 0, j = 0;
		GCD = 1;
		while (i < num1_factor.size() && j < num2_factor.size()) {
			if (num1_factor[i] < num2_factor[j]) {
				i++;
			}
			else if (num1_factor[i] > num2_factor[j]) {
				j++;
			}
			else {
				GCD *= num1_factor[i];
				i++;
				j++;
			}
		}
		cout << "GCD : " << GCD << endl;
	}

	void Print_LCM() {
		//TO_DO: Use num1, num2, and GCD to find LCM and print the result.
		LCM = num1 / GCD * num2;
		cout << "LCM : " << LCM << endl;
	}

};

void Prime_Table() {
	is_prime.resize(INF, 1);
	is_prime[0] = is_prime[1] = 0;  //Make 0 and 1 not prime number.
	for (int i = 2; i < INF; i++) { //Find all the prime numbers that are smaller than 10^7.
		if (is_prime[i] == true) {	//If the number is prime number.
			prime.push_back(i);		//Add it to the prime number vector.
			for (int j = 2 * i; j < INF; j += i) {	//Remove all the multiples of the prime number to not prime number.
				is_prime[j] = false;
			}
		}
	}
}

int main() {
	int n;
	cin >> n;
	Prime_Table();
	for (int i = 0; i < n; i++) {
		int a, b;
		cin >> a >> b;

		cout << "num1 = " << a << endl;
		cout << "num2 = " << b << endl;

		PrimeFactorization PF(a, b);

		PF.Get_Prime_Factorization();
		PF.Print_Prime_Factorization();
		PF.Print_GCD();
		PF.Print_LCM();

		cout << endl;

	}

	system("PAUSE");
	return 0;
}
