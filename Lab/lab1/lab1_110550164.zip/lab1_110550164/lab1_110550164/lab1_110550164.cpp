﻿#include <iostream>
using namespace std;

class COMPLEX_MANAGER {

public:

	COMPLEX_MANAGER(int real, int imagine) { // A constructor, which is used to initialize the data member.
		this->real = real;	// this->real means data member while real means parameter.
		this->imagine = imagine;
	}

	void plus(int a, int b, int c, int d) {	// Plus two complex numbers.
		real = a + c;
		imagine = b + d;
	}

	void mult(int a, int b, int c, int d) { // Multiple two complex numbers.
		real = a * c - b * d;
		imagine = b * c + a * d;
	}

	void print() {	// Print the real part and the imagine part of a complex number.
		if (real && imagine) // If real and imagine are not zero.
			cout << real << ((imagine >= 0) ? "+" : "") << imagine << ((imagine == 1 || imagine == -1) ? "\bi" : "i") << endl;
		else if (real != 0 && imagine == 0) // If real is not zero but imagine is zero.
			cout << real << endl;
		else if (real == 0 && imagine != 0) // If real is zero but imagine is not zero.
			cout << imagine << ((imagine == 1 || imagine == -1) ? "\bi" : "i") << endl;
		else // Both real and imagine are zero.
			cout << "0" << endl;
	}

	int real, imagine; // The declaration of two data members.
};

COMPLEX_MANAGER complex(0, 0);

int main(void) {
	char ch;
	int n, a, b, c, d;
	cout << "How many cases (n): ";
	cin >> n;
	for (int i = 0 ; i < n ; i++) {
		cout << "Input the operation (p, +, or *) and numbers: ";
		cin >> ch;
		switch (ch) {
		case 'p':
			cin >> complex.real >> complex.imagine;
			break;
		case '+':
			cin >> a >> b >> c >> d;
			complex.plus(a, b, c, d);
			break;
		case '*':
			cin >> a >> b >> c >> d;
			complex.mult(a, b, c, d);
			break;
		}
		complex.print();
	}
	return 0;
}