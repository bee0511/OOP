#include "BST.h"
#include<iostream>
#include<queue>
using namespace std;

void BST::insert(Node* insertNode) {
	//TODO: insert a node to BST
	if (!root) {
		root = insertNode;
		return;
	}
	Node* current = root;
	while (true) {
		//cout << "getvalue" << current->getValue() << endl;
		if (insertNode->getValue() < current->getValue()) {
			if (current->getLchild() != 0)
				current = current->getLchild();
			else {
				current->setLchild(insertNode);
				return;
			}
		}
		else if (insertNode->getValue() > current->getValue()) {
			if(current->getRchild() != 0)
				current = current->getRchild();
			else {
				current->setRchild(insertNode);
				return;
			}
		}
	}
	/*if (insertNode->getValue() < current->getValue()) {
		if (current->getLchild() != 0) {
			insert(current->getLchild());
			cout << "a";
		}
		else {
			current->setLchild(insertNode);
			return;
		}
		return;
	}
	if (insertNode->getValue() > current->getValue()) {
		if (current->getRchild() != 0) {
			insert(current->getRchild());
		}
		else {
			current->setRchild(insertNode);
			return;
		}
		return;
	}*/
}

void BST::InOrder_traversal(Node* root)
{
	//TODO: Inorder traversal
	if (root != 0) {
		InOrder_traversal(root->getLchild());
		cout << root->getValue() << " ";
		InOrder_traversal(root->getRchild());
	}
	//cout << root->getValue() << " ";
}

void BST::LevelOrder_traversal(Node* root)
{
	//TODO: Level order traversal
	queue<Node*> q;
	q.push(root);
	while (!q.empty())
	{
		Node* p = q.front(); 
		q.pop();
		cout << p->getValue() << " ";
		if (p->getLchild())  q.push(p->getLchild());
		if (p->getRchild()) q.push(p->getRchild());
	}
}


Node* BST::getRoot() {
	//TODO: return root of BST
	return root;
}